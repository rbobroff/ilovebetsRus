//
//  Bridging-Header.h
//  iLoveBetsRus
//
//  Created by Roman Bobrov on 07.12.2019.
//  Copyright © 2019 Roman Bobrov. All rights reserved.
//

#ifndef Bridging_Header_h
#define Bridging_Header_h


#endif /* Bridging_Header_h */

#import <JSQMessagesViewController/JSQMessages.h>
