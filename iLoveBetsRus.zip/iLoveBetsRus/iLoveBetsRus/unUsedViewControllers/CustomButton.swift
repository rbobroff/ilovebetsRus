//
//  CustomButton.swift
//  iLoveBetsRus
//
//  Created by Roman Bobrov on 26.08.2020.
//  Copyright © 2020 Roman Bobrov. All rights reserved.
//

/*
import UIKit

class CustomButton: UIButton {

    override func awakeFromNib() {
        setup()
    }
    func setup() {
        self.layer.cornerRadius = 5.0
        self.layer.shadowOffset = CGSize.zero
        self.layer.shadowRadius = 10.0
        self.layer.shadowColor = UIColor.white.cgColor
        self.layer.shadowOpacity = 0.3
    }
    
    func animateButton(shouldload:Bool) {
        let sp = UIActivityIndicatorView()
        sp.style = .whiteLarge
        sp.color = UIColor.white
        sp.alpha = 0.0
        sp.hidesWhenStopped = true
        sp.tag = 21
        if shouldload {
            self.addSubview(sp)
            self.setTitle("", for: .normal)
            UIView.animate(withDuration: 
        }
    }

}
*/
